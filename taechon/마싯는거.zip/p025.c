//#include <stdio.h>
//#include <stdlib.h>
//
//int main() {
//	char ch[100];
//	int i, n, score = 1, result = 0;
//	
//	scanf("%d", &n);
//	
//	for(i = 0 ; i < n ; i++)
//	{
//		scanf(" %c", &ch[i]);
//	}
//	
//	for(i = 0 ; i < n ; i++)
//	{
//		if(ch[i] == '1') 
//		{
//			result += score;
//			score++;
//		}
//		else score = 1;
//	}
//	
//	printf("%d\n", result);
//	
//	
//	return 0;
//}
