//#include <stdio.h>
//#include <stdlib.h>
//
//int main()
//{
//	int a, b, i, result = 1;
//	scanf("%d %d", &a, &b);
//
//	for (i = 2; i <= a && i <= b; i++)
//	{
//		if (a % i == 0 && b % i == 0) result = i;
//	}
//	printf("%d\n", result);
//		return 0;
//}