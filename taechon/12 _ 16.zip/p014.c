//#include <stdio.h>
//
//int main()
//{
//	double R1, R2, R3, R4, R5, result;
//
//	scanf("%lf %lf %lf %lf %lf", &R1, &R2, &R3, &R4, &R5);
//
//	result = R1 + (((R2 + R3) * R4) / (R2 + R3 + R4)) + R5;
//
//	printf("%.5lf\n", result);
//	return 0;
//}