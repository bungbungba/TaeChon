//#include <stdio.h>
//
//int main()
//{
//	int i, N, n;
//	long long sum = 0;
//
//	scanf("%d", &N);
//
//	for (i = 0; i < N; i++)
//	{
//		scanf("%d", &n);
//		sum += n;
//	}
//
//	printf("%lld\n", sum);
//
//	return 0;
//}