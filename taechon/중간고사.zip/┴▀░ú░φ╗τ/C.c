//#include <stdio.h>
//#include <stdlib.h>
//
//int main()
//{
//	int N, sum = 0, i;
//	
//	scanf("%d", &N);
//	
//	for(i = 1 ; i < N; i++)
//	{
//		if(N % i == 0) sum += i;
//	}
//	
//	if(N < sum) printf("1\n");
//	else if(N > sum) printf("-1\n");
//	else printf("0\n");	
//	
//	return 0;
//}
