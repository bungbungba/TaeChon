//#include <stdio.h>
//#include <stdlib.h>
//
//int compare(const void *a, const void *b)
//{
//	return *(int *)b - *(int *)a;
//}
//
//int main()
//{
//	int N, *arr, i;
//	
//	scanf("%d", &N);
//	
//	arr = (int *)calloc(N, sizeof(int));
//	
//	for(i = 0 ; i < N ; i++) scanf("%d", &arr[i]);
//	
//	qsort(arr, N, sizeof(int), compare);
//	
//	printf("%d\n", arr[2]);
//	
//	return 0;
//}
